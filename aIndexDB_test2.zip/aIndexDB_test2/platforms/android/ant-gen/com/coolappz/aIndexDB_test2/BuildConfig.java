/** Automatically generated file. DO NOT MODIFY */
package com.coolappz.aIndexDB_test2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}